from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from ..db import Base, engine
from ..live import event_bus
from .routes import router


templates = Jinja2Templates(directory="src/hrv_platform/templates")


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    app.state.event_bus = event_bus
    yield


app = FastAPI(title="HRV Platform", version="0.1.0", lifespan=lifespan)
app.mount("/static", StaticFiles(directory="src/hrv_platform/static"), name="static")
app.include_router(router)
