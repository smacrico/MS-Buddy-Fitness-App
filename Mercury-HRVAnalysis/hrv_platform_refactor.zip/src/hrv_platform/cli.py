from __future__ import annotations

import argparse
from datetime import date, timedelta

import uvicorn

from .api.app import app
from .db import Base, engine, session_scope
from .repository import HRVRepository


def init_db() -> None:
    Base.metadata.create_all(bind=engine)
    print("Database initialized.")


def seed_demo() -> None:
    import random

    Base.metadata.create_all(bind=engine)
    start = date.today() - timedelta(days=29)
    with session_scope() as session:
        repo = HRVRepository(session)
        for i in range(30):
            d = start + timedelta(days=i)
            repo.upsert_measurement(
                {
                    "measurement_date": d,
                    "source_name": "MyHRV_import",
                    "SD1": 30 + random.uniform(-5, 5),
                    "SD2": 40 + random.uniform(-6, 6),
                    "sdnn": 50 + random.uniform(-8, 8),
                    "rmssd": 42 + random.uniform(-7, 7),
                    "pNN50": 13 + random.uniform(-4, 4),
                    "VLF": 700 + random.uniform(-120, 120),
                    "LF": 1050 + random.uniform(-150, 150),
                    "HF": 820 + random.uniform(-100, 100),
                }
            )
    print("Demo data seeded.")


def serve(host: str = "127.0.0.1", port: int = 8000) -> None:
    uvicorn.run(app, host=host, port=port)


def main() -> None:
    parser = argparse.ArgumentParser(prog="hrv-platform")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("init-db")
    sub.add_parser("seed-demo")
    serve_parser = sub.add_parser("serve")
    serve_parser.add_argument("--host", default="127.0.0.1")
    serve_parser.add_argument("--port", type=int, default=8000)

    args = parser.parse_args()

    if args.command == "init-db":
        init_db()
    elif args.command == "seed-demo":
        seed_demo()
    elif args.command == "serve":
        serve(args.host, args.port)
